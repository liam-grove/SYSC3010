package com.example.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;

import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void login() throws ClassNotFoundException, SQLException {
        Intent intent = new Intent(this, MainWindow.class);
        EditText usernameEditText = (EditText) findViewById(R.id.usernameField);
        String username = usernameEditText.getText().toString();

        EditText passwordEditText = (EditText) findViewById(R.id.passwordField);
        String password = passwordEditText.getText().toString();

        String query = "SELECT Username,Password FROM login_information WHERE Username = \"" + username + "\" AND Password = \"" + password + "\"";
        ResultSet rs = LinkJavaMySQL.selectQuery(query);

        if(rs.next())
        {
            System.out.println("ready to close");
            startActivity(intent);
        }
        else
        {
            usernameEditText.setText(null);
            passwordEditText.setText(null);

        }

        rs.close();

    }
}
