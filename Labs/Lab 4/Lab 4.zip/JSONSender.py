# Source: https://pymotw.com/2/socket/udp.html
import json
import socket, sys, time

host = sys.argv[1]
textport = sys.argv[2]

s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
port = int(textport)
server_address = (host, port)

age = 30

x = {
    "name":"John",
    "age":age,
    "city":"New York"
}
msg1 = json.dumps(x)
y = json.loads(msg1)


while age < 40:
    
    for i in range (1,10):
        msg = json.dumps(y)
        if not len(msg):
            break
#    s.sendall(data.encode('utf-8'))
        s.sendto(msg.encode('utf-8'), server_address)
        age = age + 1
        x = {
        "name":"John",
        "age":age,
        "city":"New York"
        }
        msg2 = json.dumps(x)
        y = json.loads(msg2)


s.shutdown(1)

