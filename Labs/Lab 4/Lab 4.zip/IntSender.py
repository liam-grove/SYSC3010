# Source: https://pymotw.com/2/socket/udp.html

import socket, sys, time
import random

host = sys.argv[1]
textport = sys.argv[2]
n = sys.argv[3]
count = int(n)

s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
port = int(textport)
server_address = (host, port)

for x in range(1,count+1,1):
    int1 = random.randint(1,101) 
    int2 = str(int1)
    s.sendto(int2.encode('utf-8'), server_address)    

s.shutdown(1)

