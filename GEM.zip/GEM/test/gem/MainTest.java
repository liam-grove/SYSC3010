package gem;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Nirda
 */
public class MainTest {
    
    public MainTest() {
    }

    /**
     * Test of main method, of class Main.
     */
    @Test
    public void testMain() {
    }

    /**
     * Test of updateCurrent method, of class Main.
     * @throws java.lang.Exception
     */
    @Test
    public void testUpdateCurrent() throws Exception {
        
        
    }
    
}
