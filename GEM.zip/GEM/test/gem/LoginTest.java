package gem;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Nirda
 */
public class LoginTest {
    
    public LoginTest() {
    }

    /**
     * Test of main method, of class Login.
     */
    @Test
    public void testMain() {
    }
    
}
