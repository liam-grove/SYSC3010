/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gem;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Nirda
 */
public class OptimalConditionsTest {
    
    public OptimalConditionsTest() {
    }

    /**
     * Test of updateLabels method, of class OptimalConditions.
     */
    @Test
    public void testUpdateLabels() {
        //
    }

    /**
     * Test of updateTemp method, of class OptimalConditions.
     */
    @Test
    public void testUpdateTemp() {
    }

    /**
     * Test of updateHumidity method, of class OptimalConditions.
     */
    @Test
    public void testUpdateHumidity() {
    }

    /**
     * Test of updateLight method, of class OptimalConditions.
     */
    @Test
    public void testUpdateLight() {
    }

    /**
     * Test of updateWater method, of class OptimalConditions.
     */
    @Test
    public void testUpdateWater() {
    }

    /**
     * Test of main method, of class OptimalConditions.
     */
    @Test
    public void testMain() {
    }
    
}
